import java.util.HashMap;
import java.util.Scanner;

public class Huffman {

	public static void main(String[] args) {
		HashMap<String, String> binary = new HashMap<String, String>();
		Scanner input =new Scanner(System.in);
		System.out.println("dizini GİRİN");
		System.out.println("bu sistem x,y,z,w harfleri içindir");
		String metin=input.nextLine();
		
	
		char karakter1='x';
		int countX = 0;
		char karakter2='y';
		int countY=0;
		char karakter3='z';
		int countZ=0 ; 
		char karakter4='w';
		int countW=0;
		
		/// GİRİLEN METİNDE HER KARAKTERDEN LAÇ TANE VAR ONU BULUYORUM
		for(int i =0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter1) {
				countX++;
				
			}
			else if(metin.charAt(i)==karakter2) {
				countY++;
			}
			else if(metin.charAt(i)==karakter3) {
				countZ++;
				
			}
			else if(metin.charAt(i)==karakter4) {
				countW++;
			}
			
				
			}
		
		String[] karakterler= new String[4];
		karakterler[0]="x";
		karakterler[1]="y";
		karakterler[2]="z";
		karakterler[3]="w";
		
		int[] tekrarlar=new int[4];
		tekrarlar[0]=countX;
		tekrarlar[1]=countY;
		tekrarlar[2]=countZ;
		tekrarlar[3]=countW;
		int uzunluk=tekrarlar.length;
		
		
		// EN ÇOK TEKRAR EDEN KARAKTERE GÖRE SIRALAMA YAPTIM İNSERTİONSORT KULLANDIM
		
		
		for(int i =1; i<uzunluk; i++) { 
			for(int k=i ;k>0 ; k-- ) {
				if(tekrarlar[k]<tekrarlar[k-1]) {
					int gecici=tekrarlar[k];
					tekrarlar[k]=tekrarlar[k-1];
					tekrarlar[k-1]=gecici;
					String  gecici1 = karakterler[k];
					karakterler[k]=karakterler[k-1];
					karakterler[k-1]=gecici1;
				}	
			}
		}
			//BİNARY KARŞILIKLARINI VERDİM
			//SIRALI BİR ŞEKİLDE
		    binary.put(karakterler[0], "00");
	        binary.put(karakterler[1], "01");
	        binary.put(karakterler[2], "10");
	        binary.put(karakterler[3], "11");
	        
	        
	        //BİNARY KARŞILIKLARINI YAZDIRDIM
		      for(int i=0;i<metin.length();i++){
		          System.out.print(metin.subSequence(i, i+1)+"  ");
		          
		      }
		        System.out.println("" );
		      for(int i=0;i<metin.length();i++){
		          System.out.print(binary.get(metin.subSequence(i,i+1))+" ");
		          
		      } 
		

		
		}

	}


